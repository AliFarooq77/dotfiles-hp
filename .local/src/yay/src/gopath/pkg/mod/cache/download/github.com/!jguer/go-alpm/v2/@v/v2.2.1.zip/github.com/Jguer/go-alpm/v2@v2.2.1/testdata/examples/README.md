To build the examples, use make. The alpm library must be in your GOPATH.
