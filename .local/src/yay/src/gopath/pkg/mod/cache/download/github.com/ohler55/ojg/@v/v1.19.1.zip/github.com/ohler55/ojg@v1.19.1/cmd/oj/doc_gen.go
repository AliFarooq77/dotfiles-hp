//go:generate sh ./doc_gen.sh

// Package main is the main package. (stupid comment to satisfy the linter).
package main
